package com.lec.ex4_object;

public class QuizPoint3DMain {
	public static void main(String[] args) {
		Point3D[] p3s = {new Point3D(), new Point3D(1.2, 3, 5), new Point3D()};
		System.out.println(p3s[0]);
		System.out.println(p3s[0].equals(p3s[2]));
		System.out.println(p3s[0].equals(p3s[1]));
		
	}
}
